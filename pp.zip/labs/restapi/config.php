<?php

define("CLIENT_ID", "3MVG9yZ.WNe6byQB5PG2Q6CoZzp0DSsqAM8byLGNp4_XrQsybGQYJhTfA2sJc3MIV3xBxnauwi_1ELELZcFg1");

define("CLIENT_SECRET", "5674255619734379735");

define("REDIRECT_URI", "http://localhost/www/labs/restapi/callbach.php");

define("LOGIN_URI", "https://login.salesforce.com");

?>
