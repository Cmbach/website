<?php

    //$nbs_debug = TRUE;
    $nbs['status'] = NULL;
    $nbs['ssn']['facebook'] = FALSE;
    $nbs['ssn']['twitter'] = FALSE;
    $nbs['ssn']['youtube'] = FALSE;
    $nbs['ssn']['soundcloud'] = FALSE;
    $nbs['ssn']['fm'] = FALSE;
    
     

function md_get_nbs_data($artistname)
  {
    global $nbs_debug;
    //set 61 as 2 months
    global $nbs;
    $days = 61;
    $start = time() - 86400*$days;
    $end = time();
    $max_cache_day = 7;
    $nbs['update']=$end;
    //$type = "profile";
    $type = "artist";
    
    if(nbs_get_cache($artistname))
      {
        $nbs = nbs_get_cache($artistname);
        if ( ($end - $nbs['update'])/86400 < $max_cache_day)
          {
            if ($nbs_debug)
              {
                print "I get the fresh cache !!!:<br>\n";
              }
            return $nbs;
          }
        else 
          {
            if ($nbs_debug)
              {
                print "I get the OLD cache,rebuilding....:<br>\n";
              }
          }
      }
      
    if($id = search_artist($artistname))
      {
        load_nbs($id,$type,$start,$end);
      }
    else
      {
        $nbs['status'] = array(FALSE,"Artist not found in NBS");
      }
         
    $success = nbs_write_cache($artistname,$nbs);
    if ($nbs_debug)
      {
        print "Write new cache !!!<br><pre>And it is";
        echo ($success) ?  "successful" :  "failed";
        echo "</pre><br>\n";
      } 
    return $nbs;
    
  }     
     
      /*take the exact artist name
     * search in nbs 
     * reture the id if found
     * otherwise return FALSE
     * mx
     */  
     
     
function search_artist($artistname)
    {
        //global $nbs_debug;
        $url_artistname = urlencode($artistname);
        $url = "http://musicdealers.api3.nextbigsound.com/artists/search.json?q=$url_artistname";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $json_response = curl_exec($curl);
        curl_close($curl);
        $suspects =json_decode($json_response,TRUE);
        if ($nbs_debug)
          {
            print "this is the suspects:<br>\n";
            var_dump($suspects);
            echo "<br>\n";
          }
        foreach ($suspects as $id => $suspect)
          {
            if(strtolower($artistname) == strtolower($suspect['name']))
            {
              return $id;
            }
          }
        return FALSE;
    }
    
    
    
    /*
     * load social data with id.
     */
function load_nbs($id,$type,$start,$end)
  {
    global $nbs;
    $success = FALSE;
    $url = "http://musicdealers.api3.nextbigsound.com/metrics/$type/$id.json";
    $fields = array(
      'data[start]' => urlencode($start),
      'data[end]' => urlencode($end),
      'data[metric]' => urlencode("all")
    );
    foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
    rtrim($fields_string, '&');
    
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_POST,count($fields));
    curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
    $json_response = curl_exec($curl);
    curl_close($curl);
    //var_dump($json_response);die();
    $metrics = json_decode($json_response,TRUE);
    //var_dump($metrics);die();
    if($metrics['status'] == 'error')
      {
        $nbs['status'] = array(FALSE, $metrics['message']);
      }
    
    foreach($metrics as $metric)
      {
        switch ($metric["Service"]["id"]) 
          {
            case '4'://facebook
                $success = ssn_load($metric,'facebook','fans') | $success;//page-story-adds-unique
                break;
            case '5'://twitter
                $success = ssn_load($metric,'twitter','fans') | $success;//fans,friends,lists,mentions,retweets,statuses
                break;
            case '7'://youtube
                $success = ssn_load($metric,'youtube','plays') | $success;//fans,views,likes,favorites,raters
                break;
            case '10'://soundcloud
                $success = ssn_load($metric,'soundcloud','plays') | $success;//comments, downloads
                break;
            case '2'://fm
                $success = ssn_load($metric,'fm','plays') | $success;//plays,fans,comments
                break;
            default:
                break;
          }
      }
  if ($success)
    {
      $nbs['status'] = array(TRUE);
    }
  else
    {
      $nbs['status'] = array(FALSE,"This artist has not infomation we are looking for");
    }
}        
    
    
    /*
     * support function for load_nbs
     * load data to $nbs[]
     */
function ssn_load($metric,$ssn_type,$metric_type = 'fans'){
        global $nbs;
        $ssn_type == 'soundcloud' ? $rate = 0.5 : $rate = 1 ;
        $nbs['ssn'][$ssn_type]['url'] = $metric['Profile']['url'];
        $ini = TRUE;
        foreach ($metric['Metric'][$metric_type] as $count)
        {
          if($count < 0)
            {
              $count *= -1;
            }
          if($ini)//init
            {
              $nbs['ssn'][$ssn_type]['type'] = $metric_type;
              $base = $count;
              $yesterday = $count;
              $ini = FALSE;
              continue;
            }
          else
            {
              $nbs['ssn'][$ssn_type]['sum'][] = $count;
              ($count - $yesterday) < 0 ? $nbs['ssn'][$ssn_type]['today'][] = 0 : $nbs['ssn'][$ssn_type]['today'][] = ($count - $yesterday);
              $nbs['ssn'][$ssn_type]['percent'][] = (($count-$base)/$base)*100* $rate + 2;
              $yesterday = $count;
              $nbs['ssn'][$ssn_type]['last'] = $count;
            }
        }
        if($nbs['ssn'][$ssn_type]['last'] > 100)
          {
            return TRUE;
          }
        else
          {
            unset($nbs['ssn'][$ssn_type]);
            $nbs['ssn'][$ssn_type] = FALSE; 
            return FALSE;
          }
          
    }

function nbs_get_cache($artistname) 
{
  $filename = '/tmp/nbs_data/'.md5($artistname).'.json';
  
  $nbs_json = file_get_contents($filename);
  if (!$nbs_json)  
  {
    return FALSE;
  }
    return json_decode($nbs_json,TRUE);
}

function nbs_write_cache($artistname,&$nbs) {
  $filename = '/tmp/nbs_data/'.md5($artistname).'.json';
  $nbs_json = file_put_contents($filename, json_encode($nbs));
  if (!$nbs_json)  {
    //print "unable to write to $json_filepath"; die();
    //watchdog('md2_functions', 'Unable to cached  the result set to ' . $filename);
    return FALSE;
  }
  //print 'Cached the result set to: ' . $json_filepath; die();
  //no thanks
  //watchdog('md2_functions', 'Cached the result set to: ' . $filename);
  return TRUE;
}
?>