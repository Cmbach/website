<?php
  $as[3][5]='a';
  var_dump($as);
  echo "\n";
  unset($as);
  var_dump($as);
  echo "\n";
?>