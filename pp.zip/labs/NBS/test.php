<?php
    $info = '';
    isset($_POST['artist']) ? $artistname = trim($_POST['artist']) : $artistname = "the ivorys";
    include("call_nbs.php");
    //die();
   $max_ss = 4;
    
    $nbs = md_get_nbs_data($artistname);
    
    if($nbs['status'][0] === FALSE)
      {
        $output .= "<h1>No valid data for \"$artistname\"</h1><br>";
        $output .= "<h1>... ". $nbs['status'][1]."...";
        die();
      }
        
    //var_dump ($nbs);
    
    $chart_output = '';
    $index = 0;
    foreach ($nbs['ssn'] as $ss_name => $ss_data)
      { 
        if($ss_data != FALSE && $index++ < $max_ss)
          {
            $chart_output .='var '. $ss_name.'_data = [';
            foreach ($ss_data['percent'] as $votes)
              {
                $chart_output .= "$votes,";
              }
            $chart_output = trim($chart_output,',');
            $chart_output .= "];\n";
            $chart_output .="
                var chart = new Chart('".$ss_name."_chartNode');  
              // Set the theme  
                chart.setTheme(theme);
 
              // Add the only/default plot
                chart.addPlot('default', {
                  type: 'StackedAreas',
                  markers: false
                });

                chart.addAxis('x',{ majorTickStep:1000 });
                chart.addAxis('y', { min:0.1, max: 12 ,vertical: true, majorTickStep:1000,majorLabels:false});
 
                chart.addSeries('".$ss_name."',".$ss_name."_data);
                chart.render();
                
                ";
          }
      }
    

    $output .='
<html>
    <head>
      <!DOCTYPE html>
      <title>test</title>
      <style>
        h1,h2
        {
          margin: 4px;
        }
      </style>
       <script src="http://ajax.googleapis.com/ajax/libs/dojo/1.8.0/dojo/dojo.js"></script>
       <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
       
       <script>
require([
     // Require the basic 2d chart resource: Chart2D
    "dojox/charting/Chart",
 
    // Require the theme of our choosing
    "dojox/charting/themes/Dollar",
 
    // Charting plugins:
 
    //  We want to plot StackedAreas
    "dojox/charting/plot2d/StackedAreas",
 
    //  We want to use Markers
    "dojox/charting/plot2d/Markers",
 
    //  We\'ll use default x/y axes
    "dojox/charting/axis2d/Default",
 
    // Wait until the DOM is ready
    "dojo/domReady!"
], function(Chart, theme) {
    // Define the data
    ';
    $output .= $chart_output;
    $output .=' 
    $(document).ready(function(){
    $("#youtube_chartNode g g g polyline").attr("fill","rgb(195, 17, 13)");
    $("#twitter_chartNode g g g polyline").attr("fill","rgb(0, 132, 180)");
    $("#fm_chartNode g g g polyline").attr("fill","rgb(226, 19, 3)");
    $("#facebook_chartNode g g g polyline").attr("fill","rgb(59, 89, 152)");
    $("#soundcloud_chartNode g g g polyline").attr("fill","rgb(255, 85, 0)");
    
    $("#youtube_chartNode g g g polyline").attr("stroke","rgb(195, 17, 13)");
    $("#twitter_chartNode g g g polyline").attr("stroke","rgb(0, 132, 180)");
    $("#fm_chartNode g g g polyline").attr("stroke","rgb(226, 19, 3)");
    $("#facebook_chartNode g g g polyline").attr("stroke","rgb(59, 89, 152)");
    $("#soundcloud_chartNode g g g polyline").attr("stroke","rgb(255, 85, 0)");
    });
});
 
</script>
    </head>
    <body>
      <form action="test.php" method="POST">
           <label>type your artist here</label> 
           <input type="text" name="artist" />
           <br>
           <!--<label>Days you are looking for</label> 
           <select name="days">
             <option value="3">3</option>
             <option value="7" selected="selected">7</option>
             <option value="14">14</option>
             <option value="30">30</option>
             <option value="60">60</option>
           </select>-->
           <input type="submit" />
        </form>
        <br/>
        ';

    $output .= $info;
    $index = 0;
   
    foreach ($nbs['ssn'] as $ss_name => $ss_data)
      {
        if($ss_data != FALSE && $index++ < $max_ss)
          {
            $output .= '<div id="'.$ss_name.'_chartNode" style="width:360px;height:120px;"></div>';
            $output .= "<h2>$ss_name data</h2>";
            $output .= "<h2>Total ".$ss_data['last']." ".$ss_data['type']." !</h2>";
          }
      }

     $output .=  '</body>
                  </html>
                  ';
                  
                  echo $output;
?>
