<?php

$json='{
  "1": {
    "name": "MYSPACE",
    "human": "MySpace"
  },
  "2": {
    "name": "LAST.FM",
    "human": "Last.fm"
  },
  "4": {
    "name": "FACEBOOK",
    "human": "Facebook"
  },
  "5": {
    "name": "TWITTER",
    "human": "Twitter"
  },
  "7": {
    "name": "YOUTUBE",
    "human": "YouTube"
  },
  "8": {
    "name": "REVERBNATION",
    "human": "ReverbNation"
  },
  "10": {
    "name": "SOUNDCLOUD",
    "human": "SoundCloud"
  },
  "11": {
    "name": "PUREVOLUME",
    "human": "Purevolume"
  },
  "16": {
    "name": "VIMEO",
    "human": "Vimeo"
  },
  "17": {
    "name": "WIKIPEDIA",
    "human": "Wikipedia"
  },
  "25": {
    "name": "VEVO",
    "human": "Vevo"
  },
  "33": {
    "name": "RDIO",
    "human": "Rdio"
  },
  "36": {
    "name": "PANDORA",
    "human": "Pandora"
  },
  "45": {
    "name": "BANDCAMP",
    "human": "Bandcamp"
  },
  "52": {
    "name": "INSTAGRAM",
    "human": "Instagram"
  }
}';

$ssm = json_decode($json,true);
foreach ($ssm as $id =>$ar)
{
    $social[$id] = $ar['name'];
}
/*
print_r($social);
 Array
(
    [1] => MYSPACE
    [2] => LAST.FM
    [4] => FACEBOOK
    [5] => TWITTER
    [7] => YOUTUBE
    [8] => REVERBNATION
    [10] => SOUNDCLOUD
    [11] => PUREVOLUME
    [16] => VIMEO
    [17] => WIKIPEDIA
    [25] => VEVO
    [33] => RDIO
    [36] => PANDORA
    [45] => BANDCAMP
    [52] => INSTAGRAM
)
 * 
 */

$md_ss = array(
'MYSPACE'=>'1','FACEBOOK'=>'4','TWITTER'=>5,
'YOUTUBE'=>'7','SOUNDCLOUD'=>'10')

?>