<?php

class md2_nbs
  {
    protected  $nbs = array();
    protected  $nbs_debug = FALSE;
    public $artistname;
    
    public function __construct($art)
      {
        $this->artistname = $art;
        $this->nbs['status'] = NULL;
        $this->nbs['ssn']['facebook'] = FALSE;
        $this->nbs['ssn']['twitter'] = FALSE;
        $this->nbs['ssn']['youtube'] = FALSE;
        $this->nbs['ssn']['soundcloud'] = FALSE;
        $this->nbs['ssn']['fm'] = FALSE;
      }
     
     /*
      * main function 
      */

    public function md_get_nbs_data()
      {
        //set 61 as 2 months
        $days = 61;
        $start = time() - 86400*$days;
        $end = time();
        $max_cache_day = 7;
        $this->nbs['update']=$end;
        //$type = "profile";
        $type = "artist";
    
        if($this->nbs_get_cache())
          {
            $this->nbs = $this->nbs_get_cache();
            if ( ($end - $thisnbs['update'])/86400 < $max_cache_day)
              {
                if ($this->nbs_debug)
                  {
                    print "I get the fresh cache !!!:<br>\n";
                  }
                return $this->nbs;
              }
            else 
              {
                if ($this->nbs_debug)
                  {
                    print "I get the OLD cache,rebuilding....:<br>\n";
                  }
              }
          }
        
        else if($id = $this->search_artist())
          { 
            $this->load_nbs($id,$type,$start,$end);
          }   
        else
          {
            $this->nbs['status'] = array(FALSE,"Artist not found in NBS");
          } 
         
        $success = $this->nbs_write_cache();
        if ($this->nbs_debug)
          {
            print "Write new cache !!!<br><pre>And it is ";
            echo ($success) ?  "successful" :  "failed";
            echo "</pre><br>\n";
          } 
        return $this->nbs;
    
           
      }    
     
    /*
     * take the exact artist name
     * search in nbs 
     * reture the id if found
     * otherwise return FALSE
     * mx
     */  
    protected function search_artist()
      {
        //global $this->nbs_debug;
        $url_artistname = urlencode($this->artistname);
        $url = "http://musicdealers.api3.nextbigsound.com/artists/search.json?q=$url_artistname";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $json_response = curl_exec($curl);
        curl_close($curl);
        $suspects =json_decode($json_response,TRUE);
        if ($this->nbs_debug)
          {
            print "this is the suspects:<br>\n";
            var_dump($suspects);
            echo "<br>\n";
          }
        foreach ($suspects as $id => $suspect)
          {
            if(strtolower($this->artistname) == strtolower($suspect['name']))
            {
              return $id;
            }
          }
        return FALSE;
      }
    
    
    
    /*
     * load social data with id.
     */
    private function load_nbs($id,$type,$start,$end)
      {
        $success = FALSE;
        $url = "http://musicdealers.api3.nextbigsound.com/metrics/$type/$id.json";
        $fields = array(
          'data[start]' => urlencode($start),
          'data[end]' => urlencode($end),
          'data[metric]' => urlencode("all")
        );
        foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
        rtrim($fields_string, '&');
    
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_POST,count($fields));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
        $json_response = curl_exec($curl);
        curl_close($curl);
        //var_dump($json_response);die();
        $metrics = json_decode($json_response,TRUE);
        //var_dump($metrics);die();
        if($metrics['status'] == 'error')
          {
            $this->nbs['status'] = array(FALSE, $metrics['message']);
          }   
    
        foreach($metrics as $metric)
          {
            switch ($metric["Service"]["id"]) 
              {
            case '4'://facebook
                $success = $this->ssn_load($metric,'facebook','fans') | $success;//page-story-adds-unique
                break;
            case '5'://twitter
                $success = $this->ssn_load($metric,'twitter','fans') | $success;//fans,friends,lists,mentions,retweets,statuses
                break;
            case '7'://youtube
                $success = $this->ssn_load($metric,'youtube','plays') | $success;//fans,views,likes,favorites,raters
                break;
            case '10'://soundcloud
                $success = $this->ssn_load($metric,'soundcloud','plays') | $success;//comments, downloads
                break;
            case '2'://fm
                $success = $this->ssn_load($metric,'fm','plays') | $success;//plays,fans,comments
                break;
            default:
                break;
              }
          }
      if ($success)
        {
          $this->nbs['status'] = array(TRUE);
        }
      else
        {
          $this->nbs['status'] = array(FALSE,"This artist has not infomation we are looking for");
        }
    }        
    
    
    /*
     * support function for load_nbs
     * load data to $nbs[]
     */
    private function ssn_load($metric,$ssn_type,$metric_type = 'fans')
      {
        
        $ssn_type == 'soundcloud' ? $rate = 0.5 : $rate = 1 ;
        $this->nbs['ssn'][$ssn_type]['url'] = $metric['Profile']['url'];
        $ini = TRUE;
        foreach ($metric['Metric'][$metric_type] as $count)
        {
          if($count < 0)
            {
              $count *= -1;
            }
          if($ini)//init
            {
              $this->nbs['ssn'][$ssn_type]['type'] = $metric_type;
              $base = $count;
              $yesterday = $count;
              $ini = FALSE;
              continue;
            }
          else
            {
              $this->nbs['ssn'][$ssn_type]['sum'][] = $count;
              ($count - $yesterday) < 0 ? $this->nbs['ssn'][$ssn_type]['today'][] = 0 : $this->nbs['ssn'][$ssn_type]['today'][] = ($count - $yesterday);
              $this->nbs['ssn'][$ssn_type]['percent'][] = (($count-$base)/$base)*100* $rate + 2;
              $yesterday = $count;
              $this->nbs['ssn'][$ssn_type]['last'] = $count;
            }
        }
        if($this->nbs['ssn'][$ssn_type]['last'] > 100)
          {
            return TRUE;
          }
        else
          {
            unset($this->nbs['ssn'][$ssn_type]);
            $this->nbs['ssn'][$ssn_type] = FALSE; 
            return FALSE;
          }
          
    }

    private function nbs_get_cache() 
      {
        return FALSE;
        $filename = '/var/www/html/sites/default/files/nbs/artist/'.md5($this->artistname).'.json';
        $nbs_json = file_get_contents($filename);
        if (!$nbs_json)  
          {
            return FALSE;
          }
        return json_decode($nbs_json,TRUE);
      }

    private function nbs_write_cache() 
      {
        return FALSE;
        $filename = '/var/www/html/sites/default/files/nbs/artist/'.md5($this->artistname).'.json';
        $nbs_json = file_put_contents($filename, json_encode($this->nbs));
        if (!$nbs_json)  {
          return FALSE;
        }
        return TRUE;
      }

}

$info = '';
    isset($_POST['artist']) ? $artistname = trim($_POST['artist']) : $artistname = "the ivorys";
    //die();
   $max_ss = 4;
    $nbs_obj = new md2_nbs($artistname);
    $nbs = $nbs_obj->md_get_nbs_data();
    if($nbs['status'][0] === FALSE)
      {
        $output .= "<h1>No valid data for \"$artistname\"</h1><br>";
        $output .= "<h1>... ". $nbs['status'][1]."...";
        die();
      }
        
    //var_dump ($nbs);
    
    $chart_output = '';
    $index = 0;
    foreach ($nbs['ssn'] as $ss_name => $ss_data)
      { 
        if($ss_data != FALSE && $index++ < $max_ss)
          {
            $chart_output .='var '. $ss_name.'_data = [';
            foreach ($ss_data['percent'] as $votes)
              {
                $chart_output .= "$votes,";
              }
            $chart_output = trim($chart_output,',');
            $chart_output .= "];\n";
            $chart_output .="
                var chart = new Chart('".$ss_name."_chartNode');  
              // Set the theme  
                chart.setTheme(theme);
 
              // Add the only/default plot
                chart.addPlot('default', {
                  type: 'StackedAreas',
                  markers: false
                });

                chart.addAxis('x',{ majorTickStep:1000 });
                chart.addAxis('y', { min:0.1, max: 12 ,vertical: true, majorTickStep:1000,majorLabels:false});
 
                chart.addSeries('".$ss_name."',".$ss_name."_data);
                chart.render();
                
                ";
          }
      }
    

    $output .='
<html>
    <head>
      <!DOCTYPE html>
      <title>test</title>
      <style>
        h1,h2
        {
          margin: 4px;
        }
      </style>
       <script src="http://ajax.googleapis.com/ajax/libs/dojo/1.8.0/dojo/dojo.js"></script>
       <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
       
       <script>
require([
     // Require the basic 2d chart resource: Chart2D
    "dojox/charting/Chart",
 
    // Require the theme of our choosing
    "dojox/charting/themes/Dollar",
 
    // Charting plugins:
 
    //  We want to plot StackedAreas
    "dojox/charting/plot2d/StackedAreas",
 
    //  We want to use Markers
    "dojox/charting/plot2d/Markers",
 
    //  We\'ll use default x/y axes
    "dojox/charting/axis2d/Default",
 
    // Wait until the DOM is ready
    "dojo/domReady!"
], function(Chart, theme) {
    // Define the data
    ';
    $output .= $chart_output;
    $output .=' 
    $(document).ready(function(){
    $("#youtube_chartNode g g g polyline").attr("fill","rgb(195, 17, 13)");
    $("#twitter_chartNode g g g polyline").attr("fill","rgb(0, 132, 180)");
    $("#fm_chartNode g g g polyline").attr("fill","rgb(226, 19, 3)");
    $("#facebook_chartNode g g g polyline").attr("fill","rgb(59, 89, 152)");
    $("#soundcloud_chartNode g g g polyline").attr("fill","rgb(255, 85, 0)");
    
    $("#youtube_chartNode g g g polyline").attr("stroke","rgb(195, 17, 13)");
    $("#twitter_chartNode g g g polyline").attr("stroke","rgb(0, 132, 180)");
    $("#fm_chartNode g g g polyline").attr("stroke","rgb(226, 19, 3)");
    $("#facebook_chartNode g g g polyline").attr("stroke","rgb(59, 89, 152)");
    $("#soundcloud_chartNode g g g polyline").attr("stroke","rgb(255, 85, 0)");
    });
});
 
</script>
    </head>
    <body>
      <form action="nbs_class.php" method="POST">
           <label>type your artist here</label> 
           <input type="text" name="artist" />
           <br>
           <!--<label>Days you are looking for</label> 
           <select name="days">
             <option value="3">3</option>
             <option value="7" selected="selected">7</option>
             <option value="14">14</option>
             <option value="30">30</option>
             <option value="60">60</option>
           </select>-->
           <input type="submit" />
        </form>
        <br/>
        ';

    $output .= $info;
    $index = 0;
   
    foreach ($nbs['ssn'] as $ss_name => $ss_data)
      {
        if($ss_data != FALSE && $index++ < $max_ss)
          {
            $output .= '<div id="'.$ss_name.'_chartNode" style="width:360px;height:120px;"></div>';
            $output .= "<h2>$ss_name data</h2>";
            $output .= "<h2>Total ".$ss_data['last']." ".$ss_data['type']." !</h2>";
          }
      }

     $output .=  '</body>
                  </html>
                  ';
                  
                  echo $output;
?>