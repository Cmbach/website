<?php

  include 'sudoku.inc.php';
  $UNSOLVED = 81;//when it reaches 0 the sudoku should be solved
  $DEFAULT = array(1,2,3,4,5,6,7,8,9);//default options for hints
  
  $a[][] = '';//This one record known numbers
  $b[][] = '';//This one record HINTS numbers
  $c[][] = '';//This one record deduced/confirmed ANSWERS
    
    
  if(count($_POST)>0){
    $tag = true;
  }
  else{
    $tag = false;
  }


  init($a,$b);
  $UNSOLVED = key_process($b,$c,$UNSOLVED);
  if($UNSOLVED > 0){
    guess_process_ctrl($b,$c,$UNSOLVED);
  }
  
  function guess_process_ctrl($b,$c,$un){
    $tree[0][0] = array(
      'b' => $b,
      'c' => $c,
      'un' => $un,        
    );
    
    $status = guess($tree,0,0);
    if($status !== true){
      for ($level = 1; $level < 50; $level++){
        foreach($tree[$level] as $version => $value){
          echo $level ." + "  . $version;
          if( $version > 1000){
            echo 'that is not solvalbe';
            return false;
          }
          if(guess($tree,$level,$version) === true){
            return true;
          }
        }
      }
    }
  }
  
  function guess(&$tree,$level,$version){
    $next_level = $level +1;
    $b = $tree[$level][$version]['b'];
    $c = $tree[$level][$version]['c'];
    $unsolve = $tree[$level][$version]['un'];
    for($hint = 2; $hint < 7; $hint++){
      for($i = 0;$i<9;$i++){
        for($j = 0;$j<9;$j++){
          if($b[$i][$j] !== FALSE && count($b[$i][$j]) == $hint){
            foreach ($b[$i][$j] as $test){
              $b_copy = $b;
              $c_copy = $c;
              $un_copy = $unsolve;
              echo " I guessed$i,$j to be $test <br>";
              set_answer($b_copy,$c_copy,$i,$j,$test);
              $un_copy--;
              $guess_result = key_process($b_copy,$c_copy,$un_copy);
              if($guess_result === true){
                echo " <b style='background:green'>It returns out to be right</b><br>";
                $GLOBALS['b'] = $b_copy;
                $GLOBALS['c'] = $c_copy;
                $GLOBALS['UNSOLVED'] = $un_copy;
                return TRUE;
              }
              else if ($guess_result === FALSE){
                echo " <b style='background:red'>It returns out to be wrong</b><br>";
              }
              else{
                echo " <b style='background:blue'>It returns out to be more</b><br>";
                //record unsolved new status of this level
                $tree[$next_level][] = array(
                'b' => $b_copy,
                'c' => $c_copy,
                'un' => $guess_result,
                );
              }
            }
            return false;
          }
        }
      }
    } 
  }
  


    //find_unique($b,$c);
    //advanced guess
    /*
    for($i = 0;$i<9;$i++){
      for($j = 0;$j<9;$j++){
        if($b[$i][$j] !== FALSE && count($b[$i][$j]) == 2){
          foreach ($b[$i][$j] as $guess){
            $g_a = $a;
            $g_b = $b;
            $g_c = $c;
            set_answer($g_b,$g_c,$i,$j,end($g_b[$i][$j]));
            if (find_unique($g_b, $g_c) === true){
                           
            }
          }
        }
      }
    }
     
      
    if(check_unique($b,$c)){
      continue;
    }
    else{
      break;
    }
  }
*/
    //find_unique($b,$c);
    //find_unique($b,$c);
    
  function key_process(&$b,&$c,&$unsolve){
    //global $steps;
    if($debug){
      echo "first";
        var_dump ($c);
        var_dump ($unsolve);
      }
    for($i = 0;$i<9;$i++){
      for($j = 0;$j<9;$j++){
        if($b[$i][$j] !== FALSE){
          if(count($b[$i][$j]) == 1){
            if(set_answer($b,$c,$i,$j,end($b[$i][$j]))){
              $unsolve--;
            }
            key_process($b,$c,$unsolve);
          }
          else if(count($b[$i][$j]) == 0){
            //Dead end
            return false;
          }
        }
      }
    }
    if($unsolve == 0){
      //Solved
      return true;
    }
    else{
      if($debug){
        echo "second";
        var_dump ($c);
        var_dump ($unsolve);
      }
      //Need to take further steps
      return $unsolve;
    }
  }

    //Advanced method check hints if exist 2 identical array with 2 digit like (1,3),(1,3) in a row. There should not be more 1,3 in this row.
    
     
    //output of the answer
  function get_answer($a,$b,$c,$i,$j){
    if(isset($a[$i][$j])){
      $output = $a[$i][$j];
    }
    else{
      if($b[$i][$j]){
        $output .= "<span class='hint'>";
        foreach ($b[$i][$j] as $hint){
          $output .= "$hint".",";
        }
        $output .= "</span>";
      }
      else{
        $output = "<strong>".$c[$i][$j]."</strong>";
      }
    }
    return $output;
  }
    
    
    
    
    
    //html 
    $debug = true;
    $debug = false;
    if($debug)
    {
    echo "<pre>";
    
    print_r($b);
    echo "\n";
    var_dump(count($b[0][8]));
    
    echo "</pre>";
    }
    
    
    echo "
    <html>
    <head>
    <script src='//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js'></script>
    <script src='sudoku.js'></script>
        <style type='text/css'>
        .highlight{
          background-color:#FF0 !important;
        }
        span.hint
        {
            color:gray;
            font-size:60%;
        }
table,td   {border : 1px solid
;
border-collapse:collapse;
}
strong
{
    color:red;
}
input
{
    width:20px;
}
</style>
    </head>
    <body>
        <form action='sudoku.php' method='POST' target='_blank'>
            <table>";
    if($tag)
    {
        for($i = 0;$i<9;$i++)
        {
            echo "<tr>";
        for($j = 0;$j<9;$j++)
            {
                $css_issue = css_calc($i,$j);
                $value = $a[$i][$j];
                echo "<td><input name='a$i$j' value='$value' autocomplete='off' class='puzzle $css_issue'/></td>";
            }
            echo "</tr>";
        } 
    }
    else
    {
    for($i = 0;$i<9;$i++)
        {
            echo "<tr>";
        for($j = 0;$j<9;$j++)
            {
              $css_issue = css_calc($i,$j);
              echo "<td><input name='a$i$j' autocomplete='off' class='puzzle $css_issue'/></td>";
            }
            echo "</tr>";
        } 
    }
    echo       "</table>
    <br><br><br>
    <input type='submit' style='width:60px' />
    <input type='reset' style='width:60px' />
        </form><br><br><br><table>";
    
    if ($tag)
    {
            for($i = 0;$i<9;$i++)
        {
            echo "<tr>";
        for($j = 0;$j<9;$j++)
            {
                echo "<td><label>".get_answer($a,$b,$c,$i,$j)."</label></td>";
            }
            echo "</tr>";
        } 
    }
       
    echo" </table><br>left for $UNSOLVED !!!<br>
    <a href='thoughts.html'>The Ideas and Passion to Solve a sudoku</a>
</body>
</html>
";
        
        
       
        
        
          
?>