$(document).ready(function(){
  $('input.puzzle').each(function(){
    var i = $(this).attr('name').substr(1,1);
    var j = $(this).attr('name').substr(2,1);
    i = parseInt(i);
    j = parseInt(j);
      $('input[name="a'+i+j+'"]').focus(function(){
        $(this).addClass('highlight');
        $(this).keyup(function(e){
          if(e.keyCode == 38){
            m = i-1;
            n = j;
            m = m < 0 ? 0 : m;
            $('input[name="a'+m+n+'"]').focus();
          }
          if(e.keyCode == 40){
            m= i + 1;
            n=j;
            m = m > 8 ? 8 : m;
            $('input[name="a'+m+n+'"]').focus();
          }
          if(e.keyCode == 37){
            m=i;
            n=j-1;
            if(n < 0){
              m = m == 0 ? 0 : m - 1;
              n = 8;
            }
            $('input[name="a'+m+n+'"]').focus();
          }
          if(e.keyCode == 39){
            m = i ;
            n = j + 1 ;
            if( n > 8){
              m = m == 8 ? 8 : m + 1;
              n = 0;
            }
            $('input[name="a'+m+n+'"]').focus();
          }
        });
      
        $('input[name="a'+i+j+'"]').focusout(function(){
          $(this).removeClass('highlight');
        });
      }); 
    });
    
    $('input.style-A').css('background','#CEE').parent().css('background','#CEE');
    $('input.style-B').css('background','#EEE').parent().css('background','#EEE');
    $('td').css('border','1px solid #FFF');
    $('input.style-B,input.style-A').css({opacity:"0.5",border:"none"});
})

// css('background','#FFE')
/*37 - left

38 - up

39 - right

40 - down
*/