<?php

/*
 *initialize matrix from web 
 * 
 */
function init(&$a,&$b){
  for($i = 0;$i<9;$i++){
    for($j = 0;$j<9;$j++){
      $get_matrix = 'a'."$i"."$j";
      if(!empty($_POST["$get_matrix"])){
        $a[$i][$j] = intval($_POST["$get_matrix"]);
        $b[$i][$j] = FALSE;
        $GLOBALS['UNSOLVED']--;
      }
      else{
        $a[$i][$j] = NULL;
        $b[$i][$j] = $GLOBALS['DEFAULT'];
      }
    }
  } 
  for($i = 0;$i<9;$i++){
    for($j = 0;$j<9;$j++){
      if(isset($a[$i][$j])){
        clear_hint($b,$i,$j,$a[$i][$j]);
      }
    }
  }  
}

function set_answer(&$b,&$c,$i,$j,$answer){
  $c[$i][$j] = $answer;
  $b[$i][$j] = False;
  clear_hint($b,$i,$j,$answer);
  return true;
}   
  
  
/**
 * clear all the hints after set the answer
 */
function clear_hint(&$b,$i,$j,$answer){
  clear_row($b,$i,$answer);
  clear_col($b,$j,$answer);
  clear_box($b,$i,$j,$answer); 
}
function clear_row(&$b,$i,$answer){
  for($j = 0;$j<9;$j++){
    if($b[$i][$j]){
      if(($index = array_search($answer,$b[$i][$j]))!==FALSE){
        unset($b[$i][$j][$index]);
      }
    }         
  }
}   
function clear_col(&$b,$j,$answer){
  for($i = 0;$i<9;$i++){
    if($b[$i][$j]){
      if(($index = array_search($answer,$b[$i][$j]))!==FALSE){
        unset($b[$i][$j][$index]);
      }
    }
  }
}
function clear_box(&$b,$i,$j,$answer){
  $x = intval(($j)/3);
  $y = intval(($i)/3);
  //$x $y calculate the location of which 3*3 box
  for($i = $y*3;$i<($y+1)*3;$i++){
    for($j =$x*3 ;$j<($x+1)*3;$j++){
      if($b[$i][$j]){
        if(($index = array_search($answer,$b[$i][$j]))!==FALSE){
          unset($b[$i][$j][$index]);
        }
      }
    }
  }
}


//TODO adv

function adv_clear_hint(&$b,&$c)
    {
        return adv_clear_row($b,$c)||adv_clear_col($b,$c)||adv_clear_box($b,$c);
    }
    
    function adv_clear_row(&$b,&$c)
    {
        $tag = FALSE;
        for($i = 0;$i<9;$i++)
            {
            $tmp = array();
            for($j = 0;$j<9;$j++)
                if($b[$i][$j] !== FALSE)
                {
                    foreach($b[$i][$j] as $value)
                        $tmp[$value]++;
                    if(count($b[$i][$j])==2)
                        {
                            //suspicious
                            $sus[$j]=$b[$i][$j];
                        }
                }
            foreach($tmp as $key => $test)
                if ($test == 1)
                    for($j = 0;$j<9;$j++)
                        if($b[$i][$j] !== FALSE && ($index = array_search($key,$b[$i][$j]))!==FALSE)
                            {set_answer($b, $c, $i, $j, $b[$i][$j][$index]); $tag = TRUE;}
                            
            if(count($sus)>1)
                if($tmp1 = check_equal_array($sus,'a'))
                    for($j = 0;$j<9;$j++)
                        if($b[$i][$j] && !in_array($j,array_keys($tmp1)))
                            foreach($tmp1 as $kill)
                                if (($index = array_search($kill,$b[$i][$j]))!==FALSE)
                                    {unset_hint($b,$i,$j,$index); $tag = TRUE; print "I killed $i,$j with $kill.\n";}
            
            //print_r($tmp);
            //print "<br>";       
            }
            //print "<h2>row checked </h2><br><br>";
            //die();
        return $tag;
    }
    function adv_clear_col(&$b,&$c)
    {
        $tag = FALSE;
        for($j = 0;$j<9;$j++)
            {
            $tmp = array();
            for($i = 0;$i<9;$i++)
               if($b[$i][$j] !== FALSE)
                {
                    foreach($b[$i][$j] as $value)
                        $tmp[$value]++;
                    if(count($b[$i][$j])==2)
                        {
                            //suspicious
                            $sus[$i]=$b[$i][$j];
                        }
                }
                
            foreach($tmp as $key => $test)
                if ($test == 1)
                    for($i = 0;$i<9;$i++)
                        if($b[$i][$j] !== FALSE && ($index = array_search($key,$b[$i][$j]))!==FALSE)
                            {set_answer($b, $c, $i, $j, $b[$i][$j][$index]);$tag = TRUE;}
                            
            if(count($sus)>1)
                if($tmp1 = check_equal_array($sus,'a'))
                    for($i = 0;$i<9;$i++)
                        if($b[$i][$j] && !in_array($i,array_keys($tmp1)))
                            foreach($tmp1 as $kill)
                                if (($index = array_search($kill,$b[$i][$j]))!==FALSE)
                                    {unset_hint($b,$i,$j,$index); $tag = TRUE;print "I killed $i,$j with $kill.\n";}
            //print_r($tmp);
            //print "<br>";
            }
            //print "<h2>col checked </h2><br><br>";
            //die();
        return $tag; 
    }
    function adv_clear_box(&$b,&$c)
    {
        $tag = FALSE;

    for($y=0;$y<3;$y++)
    {
        for($x=0;$x<3;$x++)
        {
                
        $tmp = array();
        for($i=$y*3;$i<($y+1)*3;$i++)
            {
            for($j=$x*3;$j<($x+1)*3;$j++)               
                if($b[$i][$j] !== FALSE)
                {
                    foreach($b[$i][$j] as $value)
                        $tmp[$value]++;
                    if(count($b[$i][$j])==2)
                        {
                            //suspicious
                            $sus[$i]=$b[$i][$j];
                        }
                }
            }
        foreach($tmp as $key => $test)
            if ($test == 1)
                for($i=$y*3;$i<($y+1)*3;$i++)
                    for($j=$x*3;$j<($x+1)*3;$j++)
                        if($b[$i][$j] !== FALSE && ($index = array_search($key,$b[$i][$j]))!==FALSE)
                            {set_answer($b, $c, $i, $j, $b[$i][$j][$index]);$tag = TRUE;}
                            
                            
        if(count($sus)>1)
            if($tmp1 = check_equal_array($sus,'b'))
                for($i=$y*3;$i<($y+1)*3;$i++)
                    for($j=$x*3;$j<($x+1)*3;$j++)
                        if($b[$i][$j] && !in_array(intval(($i+1)*10+$j),array_keys($tmp1)))
                            foreach($tmp1 as $kill)
                                if (($index = array_search($kill,$b[$i][$j]))!==FALSE)
                                    {unset_hint($b,$i,$j,$index); $tag = TRUE; print "I killed $i,$j with $kill.\n";}
        //print_r($tmp);
        //print "<br>";
        }
        return $tag;
        
        
    }
    //print "<h2>box checked </h2><br><br>";
    //die();
    }


function check_equal_array($sus,$type)
    { 
        $key[] = array();
        $value[] = array();
        
        if($type === 'a')
        {
            foreach ($sus as $l => $m) 
            {
                $key[] = $l;
                $value[] = $m;
            }
        }
        else if($type === 'b')
        {
            return false;
            foreach ($sus as $l => $sus2) 
                foreach ($sus2 as $n => $m)
                {
                    $key[] = intval(($l+1)*10) + $n;
                    $value[] = $m;
                }
                 
        }
        for($i = 0 ; $i < count($key)-1 ;$i++)
                for($j = $i+1; $j <count($key);$j++)
                    {
                        if(!(array_diff($value[$i],$value[$j]) || array_diff($value[$j],$value[$i])))
                        {
                            return array($key[$i]=>$value[$i],$key[$j]=>$value[$j]);
                            echo "find some $key[$i]=>$value[$i],$key[$j]=>$value[$j]\n";          
                        }
                    }
        return FALSE;
    }

function css_calc($i,$j){
  $i = floor($i/3);
  $j = floor($j/3);
  $style = ($i+$j) % 2 == 1 ? 'style-B' : 'style-A';
  return $style;
}
?>