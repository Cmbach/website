<?php

$str_1 = '{"filters":[{"human":"Children","filter":"303"},{"human":"Country","filter":"331"},{"human":"Drum and Bass / Jungle","filter":"352"},{"human":"Experimental Electronic","filter":"354"},{"human":"Blues","exfilter":"297"},{"human":"Barbershop","exfilter":"287"}],"vocalTypes":[{"human":"Male","filter":"1"},{"human":"Group","exfilter":"4"}],"similarto":[{"human":"A Perfect Circle","filter":"549555"},{"human":"AC Slater","filter":"214114"}],"vocalInstr":[{"human":"Remix","exfilter":"3"}],"artist":[],"album":[],"song":[],"tempo":[],"keyword":[],"city":[],"state":[],"country":[],"catalog":[],"advfilters":{}}'; 
$str_2 = '{"filters":[{"human":"Children","filter":"303"},{"human":"Drum and Bass / Jungle","filter":"352"},{"human":"Blues","exfilter":"297"},{"human":"Barbershop","exfilter":"287"},{"human":"Effects","filter":"1402"},{"human":"Nature Sounds","filter":"1663"},{"human":"Keyboards","filter":"1292"},{"human":"Guitar/Stringed","filter":"1270"}],"vocalTypes":[{"human":"Male","filter":"1"}],"similarto":[{"human":"Abba","filter":"253295"}],"vocalInstr":[{"human":"Remix","exfilter":"3"}],"artist":[],"album":[],"song":[],"tempo":[],"keyword":[],"city":[],"state":[],"country":[],"catalog":[],"advfilters":{}}';
$str_3 = '{"filters":[{"human":"Trailer","filter":"1994"},{"human":"Trip Hop","filter":"507"},{"human":"World","filter":"509"},{"human":"Strings","exfilter":"1352"}],"vocalTypes":[{"human":"Both","filter":"3"}],"similarto":[],"vocalInstr":[],"artist":[],"album":[],"song":[],"tempo":[],"keyword":[],"city":[],"state":[],"country":[],"catalog":[],"advfilters":{}}';
$str_n = '{"filters":[],"vocalTypes":[],"similarto":[],"vocalInstr":[],"artist":[{"human":"Take Cover","filter":"1608833"}],"album":[],"song":[],"tempo":[],"keyword":[{"human":"haha","filter":"haha"}],"city":[{"human":"Chicago","filter":"Chicago"}],"state":[],"country":[],"catalog":[{"human":"Covers","filter":"1765"}],"advfilters":{"timesig":"5","bpmgt":"60","bpmlt":"139","language":"6"}}';

$filter1 = (array) json_decode($str_1);
$filter2 = (array) json_decode($str_2);
$filter3 = (array) json_decode($str_3);
$filtern = (array) json_decode($str_n);

$filter1 = array('a','b','c');
$filter2 = null;

/*
print_r($filter1);
echo "\n";
print_r($filter2);
echo "\n";


$fin = count(false);

var_dump($fin);
echo "\n";
*/



//$c = 1;
$tree[1][] = array(
'b' => 'aa',
'c' => 'aa',
'un' => 4 );

$tree[1][] = array(
'b' => 'cc',
'c' => 'ss',
'un' => 8 );

var_dump($tree);
?>